#include <iostream>
#include <cstdlib>
#include <string>

using namespace std;
//202235405
typedef string element;

typedef struct {
	element* data;
	int capacity;
	int top;
} StackType;

void init_stack(StackType* s) {
	s->top = -1;
	s->capacity = 100;
	s->data = new element[s->capacity];
}

bool emp(StackType* s) {
	return (s->top == -1);
}

bool is_full(StackType* s) {
	return (s->top == (s->capacity - 1));
}

void push(StackType* s, element item) {
	if (is_full(s)) {
		s->capacity *= 2;
		s->data = (element*)realloc(s->data, s->capacity * sizeof(element));
	}
	s->data[(++s->top)] = item;
}

element pop(StackType* s) {
	if (emp(s)) {
		cout << "���� ���� ����.\n";
		exit(1);
	}
	else {
		return s->data[(s->top)--];
	}
}

class Start {
	StackType sk;
	int hack;
	string name;
	string tmp;

public:
	Start() {
		init_stack(&sk);
	}

	void starting() {
		try {
			cout << "����� �й��� �Է��ϼ���: ";
			cin >> hack;
			tmp = to_string(hack);
			push(&sk, tmp);

			cout << "����� �̸��� �Է��ϼ���: ";
			cin >> name;
			push(&sk, name);
		}
		catch (std::invalid_argument& e) {
			cout << "�ùٸ��� ���� �Է��Դϴ�. ���ڷθ� �Է��ϼ���." << endl;
			return;
		}
		catch (std::runtime_error& e) {
			cout << e.what() << endl; // ���� �޽��� ���
			return;
		}
	}

	StackType* get_sk() {
		return &sk;
	}
};

int main() {
	Start start;
	start.starting();

	StackType* sk = start.get_sk();

	cout << pop(sk) << '\n';
	cout << pop(sk) << '\n';

	delete[] sk->data;

	return 0;
}
